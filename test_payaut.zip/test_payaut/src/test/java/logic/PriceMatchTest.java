package logic;

import model.BeerType;
import model.BreadType;
import model.Item;
import org.junit.Before;
import org.junit.Test;
import utils.TestUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;

public class PriceMatchTest {

    PriceMatch SUT;

    @Test
    @Before
    public void setUp() {
        var testItemRule = TestUtils.getConfiguration().getItemRules();
        SUT = new PriceMatch(testItemRule);
    }

    @Test
    public void getReceipt_DiscountHalf() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.now(), 2));
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.now(), 2));

        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(2.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void getReceipt_DiscountHalf_OneItemFull() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.now(), 2));
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.now(), 1));

        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(2.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void getReceipt_NoDiscount() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_NEW, LocalDate.now(), 2));
        testItems.add(new Item(BreadType.BREAD_NEW, LocalDate.now(), 1));

        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(3.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void getReceipt_DiscountOld_TwoFree() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_OLD, LocalDate.now(), 2));
        testItems.add(new Item(BreadType.BREAD_OLD, LocalDate.now(), 1));

        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(1.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void getReceipt_GermanSixPack() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BeerType.BEER_GERMAN, LocalDate.now(), 2));
        testItems.add(new Item(BeerType.BEER_GERMAN, LocalDate.now(), 2));
        testItems.add(new Item(BeerType.BEER_GERMAN, LocalDate.now(), 2));

        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(1.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void getReceipt_DutchSixPack() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BeerType.BEER_DUTCH, LocalDate.now(), 6));
        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(2.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void getReceipt_BelgiumSixPack() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BeerType.BEER_BELGIAN, LocalDate.now(), 6));
        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(3.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void getReceipt_GermanFour() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BeerType.BEER_GERMAN, LocalDate.now(), 2));
        testItems.add(new Item(BeerType.BEER_GERMAN, LocalDate.now(), 2));

        List<Item> receipt = SUT.getReceipt(testItems);
        assertEquals(1, receipt.size());
        assertEquals(4.0, receipt.get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void flattenItems() {
        List<Item> flattedItemsResult = new ArrayList<>();
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_NEW, LocalDate.now(), 2));
        testItems.add(new Item(BreadType.BREAD_NEW, LocalDate.now(), 2));

        var itemsByType = testItems.stream().collect(Collectors.groupingBy(Item::getType));
        SUT.flattenItems(itemsByType, flattedItemsResult);

        assertEquals(1, flattedItemsResult.size());
        assertEquals(4, flattedItemsResult.get(0).getQuantity());
    }
}
