package logic;

import model.BreadType;
import model.Item;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class ItemFilterTest {

    private ItemFilter SUT;

    @Before
    public void setUp() {
        String date = "2021-02-01";
        // default, ISO_LOCAL_DATE
        LocalDate localDate = LocalDate.parse(date);
        SUT = new ItemFilter(localDate);
    }

    @Test
    public void filterItems_ExpiredBreadRemoved() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.parse("2021-01-20"), 2));
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.parse("2021-01-27"), 2));

        List<Item> result = SUT.filterItems(testItems);
        assertEquals(1, result.size());
    }

    @Test
    public void filterItems_AllRemoved() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.parse("2021-01-19"), 2));
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.parse("2021-01-19"), 2));

        List<Item> result = SUT.filterItems(testItems);
        assertEquals(0, result.size());
    }
}
