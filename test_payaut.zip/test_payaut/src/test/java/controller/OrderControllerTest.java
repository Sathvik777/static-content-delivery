package controller;

import logic.ItemFilter;
import logic.PriceMatch;
import model.BeerType;
import model.BreadType;
import model.Item;
import org.junit.Before;
import org.junit.Test;
import utils.TestUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class OrderControllerTest {

    private OrderController SUT;

    @Before
    public void setUp() {
        var testItemRule = TestUtils.getConfiguration().getItemRules();
        String date = "2021-02-01";
        // default, ISO_LOCAL_DATE
        LocalDate localDate = LocalDate.parse(date);
        var itemFilter = new ItemFilter(localDate);
        SUT = new OrderController(new PriceMatch(testItemRule), itemFilter);
    }

    @Test
    public void handelOrder_DiscountHalf() {
        List<Item> testItems = new ArrayList<>();
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.now(), 2));
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.now(), 2));

        var receipt = SUT.handelOrder(testItems);
        assertEquals(1, receipt.getItems().size());
        assertEquals(2.0, receipt.getItems().get(0).getPrice().doubleValue(), 0);
    }

    @Test
    public void handelOrder_DiscountTotal() {
        List<Item> testItems = new ArrayList<>();
        // Costs: 1 EUR
        testItems.add(new Item(BreadType.BREAD_MID_AGE, LocalDate.now(), 2));
        // Costs: 2 EUR
        testItems.add(new Item(BreadType.BREAD_NEW, LocalDate.now(), 2));
        // Costs: 1 EUR
        testItems.add(new Item(BreadType.BREAD_OLD, LocalDate.now(), 3));
        // Costs: 2 EUR
        testItems.add(new Item(BeerType.BEER_DUTCH, LocalDate.now(), 6));
        // Costs: 2 EUR
        testItems.add(new Item(BeerType.BEER_GERMAN, LocalDate.now(), 2));

        var receipt = SUT.handelOrder(testItems);

        assertEquals(5, receipt.getItems().size());
        assertEquals(8.0, receipt.getTotal().doubleValue(), 0);
    }
}
