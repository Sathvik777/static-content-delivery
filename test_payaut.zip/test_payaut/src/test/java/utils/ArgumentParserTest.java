package utils;

import model.BreadType;
import model.Item;
import model.ItemType;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class ArgumentParserTest {

    private ArgumentParser SUT;

    @Before
    public void setUp() throws Exception {
        String date = "2021-02-01";
        // default, ISO_LOCAL_DATE
        LocalDate localDate = LocalDate.parse(date);
        SUT = new ArgumentParser(localDate);
    }

    @Test
    public void toItems_Pos() {
        var testArgument =
                "bread,new,2021-02-01,1;bread,old,2021-02-01,1;beer,german,2021-02-01,6;";

        List<Item> result = SUT.toItems(testArgument);
        assertEquals(3, result.size());
        assertEquals(ItemType.BREAD, result.get(0).getType().getItemType());
    }

    @Test
    public void toItems_PosWithWrongSize() {
        var testArgument = "bread,new,,1;bread,old,2021-02-01,1;beer,german,2021-02-01,6;";

        List<Item> result = SUT.toItems(testArgument);
        assertEquals(2, result.size());
        assertEquals(ItemType.BREAD, result.get(0).getType().getItemType());
    }

    @Test
    public void toItems_Neg() {
        var testArgument = "breadzz,old,2021-02-01,1;beer,german,2021-02-01,6;";

        List<Item> result = SUT.toItems(testArgument);
        assertEquals(1, result.size());
        assertEquals(ItemType.BEER, result.get(0).getType().getItemType());
    }

    @Test
    public void fixBreadSubType() {
        var testArgument = "bread,new,2021-02-01,1;bread,old,2021-01-29,1;";
        List<Item> result = SUT.toItems(testArgument);
        assertEquals(2, result.size());
        assertEquals(BreadType.BREAD_MID_AGE, result.get(1).getType());
    }
}
