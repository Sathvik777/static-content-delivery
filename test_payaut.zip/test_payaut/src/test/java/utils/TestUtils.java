package utils;

import configuration.Configuration;
import configuration.ItemRule;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import org.yaml.snakeyaml.representer.Representer;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class TestUtils {

    public static Configuration getConfiguration() {
        InputStream inputStream =
                TestUtils.class.getClassLoader().getResourceAsStream("configuration-test.yaml");
        Representer representer = new Representer();
        Class<Configuration> rootConfig = Configuration.class;

        var yaml = new Yaml(new Constructor(rootConfig), representer);

        var testConf = new Configuration();
        List<ItemRule> itemRules = new ArrayList<>();

        return rootConfig.cast(yaml.load(inputStream));
    }
}
