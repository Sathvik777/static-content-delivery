package utils;

import model.BreadType;
import model.Item;
import model.ItemType;
import model.TypeInterface;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

/** Makes sure the arguments are parsed to items and can be passed other controllers */
public class ArgumentParser {

    private final LocalDate dateAfterThreeDays;
    private final LocalDate dateAfterFiveDays;

    public ArgumentParser(LocalDate dateNow) {
        this.dateAfterThreeDays = dateNow.minusDays(3);
        this.dateAfterFiveDays = dateNow.minusDays(5);
    }

    public List<Item> toItems(String argument) {
        List<Item> parsedItems = new ArrayList<>();
        Arrays.asList(argument.split(";"))
                .forEach(
                        itemAsStr -> {
                            var features = itemAsStr.split(",");

                            if (features.length == 4) {
                                try {
                                    var itemType =
                                            ItemType.getTypeWithSubType(features[0], features[1]);

                                    var manufactureDate = LocalDate.parse(features[2]);
                                    var quantity = Integer.parseInt(features[3]);
                                    parsedItems.add(
                                            new Item(
                                                    fixBreadSubType(itemType, manufactureDate),
                                                    manufactureDate,
                                                    quantity));
                                } catch (NoSuchElementException e) {
                                    System.out.println(
                                            "Could not parse the type of the item "
                                                    + e.getMessage());
                                } catch (DateTimeException e) {
                                    System.out.println(
                                            "Could not parse the manufacture date of the item "
                                                    + e.getMessage());
                                } catch (NumberFormatException e) {
                                    System.out.println(
                                            "Could not parse the quantity of the item "
                                                    + e.getMessage());
                                }
                            }
                        });
        return parsedItems;
    }

    private TypeInterface fixBreadSubType(TypeInterface type, LocalDate manufactureDate) {

        if (type.getItemType().equals(ItemType.BREAD)) {
            if (dateAfterThreeDays.isBefore(manufactureDate)) {
                return BreadType.BREAD_NEW;
            } else if ((dateAfterThreeDays.isAfter(manufactureDate)
                            || dateAfterThreeDays.isEqual(manufactureDate))
                    && (dateAfterFiveDays.isBefore(manufactureDate)
                            || dateAfterFiveDays.isEqual(manufactureDate))) {
                return BreadType.BREAD_MID_AGE;

            } else if (dateAfterFiveDays.isAfter(manufactureDate)) {
                return BreadType.BREAD_OLD;
            }
        }
        return type;
    }
}
