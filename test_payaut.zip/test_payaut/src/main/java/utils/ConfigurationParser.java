package utils;

import configuration.Configuration;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import org.yaml.snakeyaml.representer.Representer;

import java.io.*;

public class ConfigurationParser {

    public static Configuration getConfiguration() {
        InputStream inputStream =
                ConfigurationParser.class
                        .getClassLoader()
                        .getResourceAsStream("configuration.yaml");
        Representer representer = new Representer();
        Class<Configuration> rootConfig = Configuration.class;

        var yaml = new Yaml(new Constructor(rootConfig), representer);

        return rootConfig.cast(yaml.load(inputStream));
    }
}
