package configuration;

import java.util.List;

public class Configuration {
    List<ItemRule> itemRules;

    public List<ItemRule> getItemRules() {
        return itemRules;
    }

    public void setItemRules(List<ItemRule> itemRules) {
        this.itemRules = itemRules;
    }
}
