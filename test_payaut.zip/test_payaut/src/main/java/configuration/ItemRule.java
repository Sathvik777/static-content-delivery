package configuration;

import model.Amount;

public class ItemRule {
    String name;
    String parentType;
    String subType;
    Amount price = new Amount();
    Discount discountConditions = new Discount();

    public ItemRule() {}

    public String getName() {
        return name;
    }

    public String getParentType() {
        return parentType;
    }

    public String getSubType() {
        return subType;
    }

    public Amount getPrice() {
        return price;
    }

    public Discount getDiscountConditions() {
        return discountConditions;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setParentType(String parentType) {
        this.parentType = parentType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public void setPrice(Amount price) {
        this.price = price;
    }

    public void setDiscountConditions(Discount discountConditions) {
        this.discountConditions = discountConditions;
    }
}
