package configuration;

public class Discount {
    int itemCount;
    double priceAdjDiv;

    public Discount() {}

    public Discount(int itemCount, double priceAdjDiv) {
        this.itemCount = itemCount;
        this.priceAdjDiv = priceAdjDiv;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    public double getPriceAdjDiv() {
        return priceAdjDiv;
    }

    public void setPriceAdjDiv(double priceAdjDiv) {
        this.priceAdjDiv = priceAdjDiv;
    }
}
