package model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Order {

    private final List<Item> items;
    private final LocalDate date;
    private final BigDecimal total;

    public Order(List<Item> items, LocalDate date, BigDecimal total) {
        this.items = items;
        this.date = date;
        this.total = total;
    }

    public List<Item> getItems() {
        return items;
    }

    public LocalDate getDate() {
        return date;
    }

    public BigDecimal getTotal() {
        return total;
    }

    @Override
    public String toString() {
        return "{" + "items= \n" + items + ", \n date=" + date + ", \n total=" + total + '}';
    }
}
