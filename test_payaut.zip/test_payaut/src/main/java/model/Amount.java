package model;

public class Amount {
    String number;
    int scale;
    String currency;

    public Amount() {}

    public String getNumber() {
        return number;
    }

    public String getCurrency() {
        return currency;
    }

    public int getScale() {
        return scale;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
