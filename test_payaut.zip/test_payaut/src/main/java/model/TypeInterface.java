package model;

public interface TypeInterface {
    default ItemType getItemType() {
        return this.getItemType();
    }
}
