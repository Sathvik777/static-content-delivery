package model;

import java.util.Arrays;
import java.util.NoSuchElementException;

public enum ItemType implements TypeInterface {
    BREAD("bread"),
    BEER("beer");

    private String name;

    ItemType(String name) {
        this.name = name;
    }

    private static ItemType getType(String name) throws NoSuchElementException {
        return Arrays.stream(ItemType.values())
                .filter(t -> t.name.equalsIgnoreCase(name))
                .findFirst()
                .orElseThrow();
    }

    public static TypeInterface getTypeWithSubType(String parentType, String subType) {
        return (ItemType.getType(parentType) == ItemType.BEER)
                ? BeerType.getBeerType(subType)
                : BreadType.getBreadType(subType);
    }
}
