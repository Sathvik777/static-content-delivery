package model;

import java.util.Arrays;
import java.util.NoSuchElementException;

public enum BeerType implements TypeInterface {
    BEER_GERMAN("german", ItemType.BEER),
    BEER_DUTCH("dutch", ItemType.BEER),
    BEER_BELGIAN("belgium", ItemType.BEER);

    private String name;
    private ItemType itemType;

    BeerType(String name, ItemType itemType) {
        this.name = name;
        this.itemType = itemType;
    }

    public static TypeInterface getBeerType(String name) throws NoSuchElementException {
        return Arrays.stream(BeerType.values())
                .filter(t -> t.name.equalsIgnoreCase(name))
                .findFirst()
                .orElseThrow();
    }

    public ItemType getItemType() {
        return itemType;
    }
}
