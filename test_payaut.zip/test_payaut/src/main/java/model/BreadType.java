package model;

import java.util.Arrays;

public enum BreadType implements TypeInterface {
    BREAD_NEW("new", ItemType.BREAD),
    BREAD_MID_AGE("mid_age", ItemType.BREAD),
    BREAD_OLD("old", ItemType.BREAD);

    private String name;
    private ItemType itemType;

    BreadType(String name, ItemType itemType) {
        this.name = name;
        this.itemType = itemType;
    }

    public static TypeInterface getBreadType(String name) {
        return Arrays.stream(BreadType.values())
                .filter(t -> t.name.equalsIgnoreCase(name))
                .findFirst().orElseThrow();
    }

    public ItemType getItemType() {
        return itemType;
    }
}
