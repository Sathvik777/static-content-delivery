package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Item {

    private final TypeInterface type;
    private final LocalDate manufactureDate;
    private final int quantity;
    // Only mutable value
    private BigDecimal price;

    public Item(TypeInterface type, LocalDate manufactureDate, int quantity) {
        this.type = type;
        this.manufactureDate = manufactureDate;
        this.quantity = quantity;
    }

    public TypeInterface getType() {
        return type;
    }

    public LocalDate getManufactureDate() {
        return manufactureDate;
    }

    public int getQuantity() {
        return quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "{"
                + "type="
                + type
                + ", manufactureDate="
                + manufactureDate
                + ", quantity="
                + quantity
                + ", price="
                + price
                + '}'
                + '\n';
    }
}
