package controller;

import logic.ItemFilter;
import logic.PriceMatch;
import model.Item;
import model.Order;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/** Handles the order by delegating items with multiple logic classes */
public class OrderController {

    private final PriceMatch priceMatch;
    private final ItemFilter itemFilter;

    public OrderController(PriceMatch priceMatch, ItemFilter itemFilter) {
        this.priceMatch = priceMatch;
        this.itemFilter = itemFilter;
    }

    public Order handelOrder(List<Item> items) {
        var filteredItems = itemFilter.filterItems(items);
        var finalItems = priceMatch.getReceipt(filteredItems);
        var total = finalItems.stream().map(Item::getPrice).reduce(BigDecimal::add).get();
        return new Order(finalItems, LocalDate.now(), total);
    }
}
