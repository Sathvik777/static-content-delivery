package logic;

import configuration.ItemRule;
import model.Item;
import model.ItemType;
import model.TypeInterface;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Gets the list of items matches with the quantity and declares the final price of the set of units
 * grouped by type
 */
public class PriceMatch {
    private Map<TypeInterface, ItemRule> ruleMap = new HashMap<>();

    public PriceMatch(List<ItemRule> itemRules) {
        itemRules.forEach(
                it -> {
                    var type = ItemType.getTypeWithSubType(it.getParentType(), it.getSubType());
                    ruleMap.put(type, it);
                });
    }

    public List<Item> getReceipt(List<Item> items) {
        List<Item> flattedItems = new ArrayList<>();
        Map<TypeInterface, List<Item>> itemsByType =
                items.stream().collect(Collectors.groupingBy(Item::getType));
        flattenItems(itemsByType, flattedItems);
        return flattedItems.stream().peek(this::setPriceWithDiscount).collect(Collectors.toList());
    }

    private void setPriceWithDiscount(Item it) {
        var rule = ruleMap.get(it.getType());
        var pricePer =
                new BigDecimal(rule.getPrice().getNumber())
                        .setScale(rule.getPrice().getScale(), RoundingMode.FLOOR);
        int itemsOutsideDiscount = it.getQuantity() % rule.getDiscountConditions().getItemCount();

        int discountItemNum = it.getQuantity() - itemsOutsideDiscount;
        var discount = BigDecimal.valueOf(rule.getDiscountConditions().getPriceAdjDiv());
        var discountAmount =
                pricePer.multiply(BigDecimal.valueOf(discountItemNum))
                        .divide(discount, RoundingMode.FLOOR)
                        .setScale(rule.getPrice().getScale(), RoundingMode.FLOOR);

        var nonDiscountAmount = pricePer.multiply(BigDecimal.valueOf(itemsOutsideDiscount));
        it.setPrice(discountAmount.add(nonDiscountAmount));
    }

    protected void flattenItems(
            Map<TypeInterface, List<Item>> itemsByType, List<Item> flattedItems) {

        itemsByType.forEach(
                (t, it) ->
                        it.stream()
                                .findFirst()
                                .ifPresent(
                                        i -> {
                                            var totalItemsOfType =
                                                    it.stream().mapToInt(Item::getQuantity).sum();
                                            flattedItems.add(
                                                    new Item(
                                                            i.getType(),
                                                            i.getManufactureDate(),
                                                            totalItemsOfType));
                                        }));
    }
}
