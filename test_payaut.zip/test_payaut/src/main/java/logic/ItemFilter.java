package logic;

import model.Item;
import model.ItemType;
import model.TypeInterface;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * ItemFilter filters the elements from items list based on condition provided
 * per each type or
 * sub-type
 */
public class ItemFilter {

    private Map<TypeInterface, Function<Item, Boolean>> ruleMap = new HashMap<>();

    public ItemFilter(LocalDate timeNow) {
        var breadExpiresAt = timeNow.minus(6, ChronoUnit.DAYS);
        ruleMap.put(ItemType.BREAD, (it) -> it.getManufactureDate().isAfter(breadExpiresAt));
    }

    public List<Item> filterItems(List<Item> items) {
        return items.stream()
                .filter(item -> {
                    var itemType = item.getType().getItemType();
                    if (ruleMap.containsKey(itemType)) {
                        return ruleMap.get(item.getType().getItemType()).apply(item);
                    } else {
                        return true;
                    }

                })
                .collect(Collectors.toList());
    }
}
