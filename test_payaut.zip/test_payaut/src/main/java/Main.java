import controller.OrderController;
import logic.ItemFilter;
import logic.PriceMatch;
import utils.ArgumentParser;
import utils.ConfigurationParser;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
        public static void main(String[] args) {
                Map<String, String> argMap = Arrays.stream(args)
                                .collect(
                                                Collectors.toMap(
                                                                a -> {
                                                                        return a.split("=")[0];
                                                                },
                                                                a -> String.valueOf(a.split("=")[1])));
                var itemsArgStr = argMap.get("items");

                var configuration = ConfigurationParser.getConfiguration();
                var timeNow = LocalDate.now();

                var items = new ArgumentParser(timeNow).toItems(itemsArgStr);

                var orderController = new OrderController(
                                new PriceMatch(configuration.getItemRules()), new ItemFilter(timeNow));
                var receipt = orderController.handelOrder(items);
                System.out.println(receipt);
        }
}
