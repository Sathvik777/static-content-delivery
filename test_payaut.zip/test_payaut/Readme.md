# Payaut Online Grocery Store

An e-commerce grocery store has required you to implement an application that calculates the order total and prints it's receipt applying the following business rules:
- One order can have many items.
- Items can only be breads or beers.
- Breads always have discounts like "take 2 pay 1" or "take 3 pay 1”. In this type of
discount the client always pays at least 100% of one unit of bread, but he/she takes more unit(s) as a bonus). If the bread is two days old or newer, it has no discounts. If it's between 3 and 5 days old, each bread you pay makes you eligible to take one more unit for free, and if it's exactly 6 days old, the bonus is 2 extra units. Breads older than 6 days cannot be added to orders.
- Beers have only discounts if bought in packs containing 6 beers. The discount rules are fixed per packs: € 3,00 for each Belgium beer pack, € 2,00 for Dutch ones and € 1,00 for German ones. Single bottles/cans of beer can always be added to the order, but in that case there is no discount. Buying 6 separated bottles of the same beer is the same as buying one pack of the same beer.


## How to run it?

### Pre requirements
* Java 11

### Commands
To run the program
```shell script
./gradlew run --args='items=(bread|beer),(respective_subtype),(manifacture date),(quantity);'
```
example:
```shell script
./gradlew run --args='items=bread,new,2021-02-01,1;bread,old,2021-02-01,1;beer,german,2021-02-01,6;'
```

To run tests
```shell script
./gradlew test 
```